<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Appointment;
use App\Http\Resources\AppointmentResource;
use Illuminate\Http\Request;
use Exception;

class AppointmentController extends Controller
{
    public function index()
    {
        try {
            $appointments = Appointment::all();
            return $this->sendResponse(AppointmentResource::collection($appointments), 'Appointments retrieved successfully.');
        } catch (Exception $e) {
            return $this->sendError('Failed to retrieve appointments.', ['error' => $e->getMessage()]);
        }
    }

    public function store(Request $request)
    {
        try {
            $appointment = Appointment::create([
                'patient_id' => $request->patient_id,
                'provider_id' => $request->provider_id,
                'start' => $request->start,
                'end' => $request->end,
                'title' => $request->title,
                'description' => $request->description,
                'color_primary' => $request->color_primary,
                'color_secondary' => $request->color_secondary,
                'actions' => $request->actions,
                'all_day' => $request->all_day ?? false,
                'resizable_before_start' => $request->resizable_before_start ?? false,
                'resizable_after_end' => $request->resizable_after_end ?? false,
                'draggable' => $request->draggable ?? false,
            ]);

            return $this->sendResponse(new AppointmentResource($appointment), 'Appointment created successfully!');
        } catch (Exception $e) {
            return $this->sendError('Failed to create appointment.', ['error' => $e->getMessage()]);
        }
    }

    public function show($id)
    {
        try {
            $appointment = Appointment::findOrFail($id);
            return $this->sendResponse(new AppointmentResource($appointment), 'Appointment retrieved successfully!');
        } catch (Exception $e) {
            return $this->sendError('Appointment not found.', ['error' => $e->getMessage()]);
        }
    }

    public function update(Request $request, $id)
    {
        try {
            $appointment = Appointment::findOrFail($id);

            $appointment->update([
                'start' => $request->start,
                'end' => $request->end,
                'title' => $request->title,
                'description' => $request->description,
                'color_primary' => $request->color_primary,
                'color_secondary' => $request->color_secondary,
                'actions' => $request->actions,
                'all_day' => $request->all_day ?? false,
                'resizable_before_start' => $request->resizable_before_start ?? false,
                'resizable_after_end' => $request->resizable_after_end ?? false,
                'draggable' => $request->draggable ?? false,
            ]);

            return $this->sendResponse(new AppointmentResource($appointment), 'Appointment updated successfully!');
        } catch (Exception $e) {
            return $this->sendError('Failed to update appointment.', ['error' => $e->getMessage()]);
        }
    }

    public function destroy($id)
    {
        try {
            $appointment = Appointment::findOrFail($id);
            $appointment->delete();

            return $this->sendResponse([], 'Appointment deleted successfully!');
        } catch (Exception $e) {
            return $this->sendError('Failed to delete appointment.', ['error' => $e->getMessage()]);
        }
    }
}
