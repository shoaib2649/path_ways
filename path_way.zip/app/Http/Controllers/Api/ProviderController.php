<?php
namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use App\Http\Resources\ProviderResource;
use App\Models\Provider;
use App\Models\User;
use Illuminate\Http\Request;

class ProviderController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $providers = Provider::with('users')->get();
        return $this->sendResponse(ProviderResource::collection($providers), 'Provider Data');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        try {
            // Create the user first
            $user = User::create([
                'prefix' => $request->prefix,
                'first_name' => $request->first_name,
                'middle_name' => $request->middle_name,
                'last_name' => $request->last_name,
                'full_name' => $request->full_name,
                'email' => $request->email,
                'google_id' => $request->google_id,
                'password' => bcrypt($request->password),
                'user_role' => 'provider',
                'subscribe_status' => $request->subscribe_status,
                'phone' => $request->phone,
                'address' => $request->address,
                'state' => $request->state,
                'postal_code' => $request->postal_code,
                'country' => $request->country,
                'date_of_birth' => $request->date_of_birth,
                'gender' => $request->gender,
                'age' => $request->age,
                'is_active' => $request->is_active,
                'profile_image' => $request->profile_image,
                'bio' => $request->bio,
                'social_media' => $request->social_media,
                'city' => $request->city,
            ]);

            // Now create the provider record with the user_id
            $provider = Provider::create([
                'user_id' => $user->id,
                'specialization' => $request->specialization,
                'license_number' => $request->license_number,
                'license_expiry_date' => $request->license_expiry_date,
                'experience_years' => $request->experience_years,
                'education' => $request->education,
                'certifications' => $request->certifications,
                'clinic_name' => $request->clinic_name,
                'clinic_address' => $request->clinic_address,
                'available_days' => $request->available_days,
                'available_time' => $request->available_time,
                'is_verified' => $request->is_verified ?? false,
                'doctor_notes' => $request->doctor_notes,
                'consultation_fee' => $request->consultation_fee,
                'profile_slug' => $request->profile_slug,
            ]);

            return $this->sendResponse(new ProviderResource($provider), 'Provider record created successfully!');
        } catch (\Exception $e) {
            return $this->sendError('Unauthorized.', ['error' => $e->getMessage()]);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $provider = Provider::with('users')->find($id);
        if ($provider) {
            return $this->sendResponse(new ProviderResource($provider), 'Provider data retrieved successfully');
        } else {
            return $this->sendError('Provider not found.');
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        try {
            $provider = Provider::findOrFail($id);
            $provider->update([
                'specialization' => $request->specialization,
                'license_number' => $request->license_number,
                'license_expiry_date' => $request->license_expiry_date,
                'experience_years' => $request->experience_years,
                'education' => $request->education,
                'certifications' => $request->certifications,
                'clinic_name' => $request->clinic_name,
                'clinic_address' => $request->clinic_address,
                'available_days' => $request->available_days,
                'available_time' => $request->available_time,
                'is_verified' => $request->is_verified ?? false,
                'doctor_notes' => $request->doctor_notes,
                'consultation_fee' => $request->consultation_fee,
                'profile_slug' => $request->profile_slug,
            ]);
            return $this->sendResponse(new ProviderResource($provider), 'Provider record updated successfully!');
        } catch (\Exception $e) {
            return $this->sendError('Error occurred while updating the provider record.', ['error' => $e->getMessage()]);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $provider = Provider::find($id);
        if (!$provider) {
            return $this->sendError('Provider not found.');
        }
        $provider->delete();
        return $this->sendResponse(null, 'Provider deleted successfully');
    }
}

