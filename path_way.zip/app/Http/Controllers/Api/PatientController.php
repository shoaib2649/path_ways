<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\PatientResource;
use App\Models\Patient;
use App\Models\User;
use Illuminate\Http\Request;

class PatientController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $patients = Patient::with('user')->get();
        return $this->sendResponse(PatientResource::collection($patients), 'Patient Data');
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        try {
            $user = User::create([
                'prefix' => $request->prefix,
                'mrn' => $request->mrn,
                'first_name' => $request->first_name,
                'middle_name' => $request->middle_name,
                'last_name' => $request->last_name,
                'full_name' => $request->full_name,
                'email' => $request->email,
                'google_id' => $request->google_id,
                'password' => bcrypt($request->password),
                'user_role' => 'patient',
                'subscribe_status' => $request->subscribe_status,
                'phone' => $request->phone,
                'address' => $request->address,
                'state' => $request->state,
                'postal_code' => $request->postal_code,
                'country' => $request->country,
                'date_of_birth' => $request->date_of_birth,
                'gender' => $request->gender,
                'age' => $request->age,
                'is_active' => $request->is_active,
                'profile_image' => $request->profile_image,
                'bio' => $request->bio,
                'social_media' => $request->social_media,
            ]);

            $patient = Patient::create([
                'user_id' => $user->id,
                'provider_id' => $request->provider_id,
                'mr' => $request->mr,
                'suffix' => $request->suffix,
                'social_security_number' => $request->social_security_number,
                'blood_score' => $request->blood_score,
                'lifestyle_score' => $request->lifestyle_score,
                'supplement_medication_score' => $request->supplement_medication_score,
                'physical_vital_sign_score' => $request->physical_vital_sign_score,
                'image' => $request->image,
                'module_level' => $request->module_level,
                'qualification' => $request->qualification,
                'provider_name' => $request->provider_name,
                'status' => $request->status,
                'wait_list' => $request->wait_list,
                'group_appointments' => $request->group_appointments,
                'individual_appointments' => $request->individual_appointments,
                'location' => $request->location,
            ]);

            return $this->sendResponse(new PatientResource($patient), 'Patient record created successfully!');
        } catch (\Exception $e) {
            return $this->sendError('Unauthorized.', ['error' => $e->getMessage()]);
        }
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $patient = Patient::with('user')->find($id);
        if (!empty($patient)) {
            return $this->sendResponse(new PatientResource($patient), 'Patient record retrieved successfully');
        } else {
            return $this->sendError('Error occurred while showing the record.');
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        try {
            $patient = Patient::findOrFail($id);
            $patient->update([
                'provider_id' => $request->provider_id,
                'mr' => $request->mr,
                'suffix' => $request->suffix,
                'social_security_number' => $request->social_security_number,
                'blood_score' => $request->blood_score,
                'lifestyle_score' => $request->lifestyle_score,
                'supplement_medication_score' => $request->supplement_medication_score,
                'physical_vital_sign_score' => $request->physical_vital_sign_score,
                'image' => $request->image,
                'module_level' => $request->module_level,
                'qualification' => $request->qualification,
                'provider_name' => $request->provider_name,
                'status' => $request->status,
                'group_appointments' => $request->group_appointments,
                'individual_appointments' => $request->individual_appointments,
                'location' => $request->location,
            ]);

            return $this->sendResponse(new PatientResource($patient), 'Patient record updated successfully!');
        } catch (\Exception $e) {
            return $this->sendError('Error occurred while updating the patient record.', ['error' => $e->getMessage()]);
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $patient = Patient::find($id);
        if (!$patient) {
            return $this->sendError('Patient not found.');
        }
        $patient->delete();
        return $this->sendResponse([], 'Patient deleted successfully!');
    }
}
