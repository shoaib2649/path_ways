<?php

namespace App\Http\Resources;

use Illuminate\Http\Request;
use Illuminate\Http\Resources\Json\JsonResource;

class AppointmentResource extends JsonResource
{
    /**
     * Transform the resource into an array.
     *
     * @return array<string, mixed>
     */
    public function toArray(Request $request): array
    {
        return [
            'id' => $this->id,
            'patient_id' => $this->patient_id,
            'provider_id' => $this->provider_id,
            'start' => $this->start,
            'end' => $this->end,
            'title' => $this->title,
            'description' => $this->description,
            'color_primary' => $this->color_primary,
            'color_secondary' => $this->color_secondary,
            'actions' => $this->actions,
            'all_day' => $this->all_day,
            'resizable_before_start' => $this->resizable_before_start,
            'resizable_after_end' => $this->resizable_after_end,
            'draggable' => $this->draggable,
            'created_at' => $this->created_at,
            'updated_at' => $this->updated_at,
        ];
    }
}
