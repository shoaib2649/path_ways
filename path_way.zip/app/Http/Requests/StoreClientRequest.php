<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreClientRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return false;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
           
                // User validation rules
                'prefix' => 'nullable|string|max:10',
                'first_name' => 'nullable|string|max:255',
                'middle_name' => 'nullable|string|max:255',
                'last_name' => 'nullable|string|max:255',
                'full_name' => 'nullable|string|max:255',
                'name' => 'nullable|string|max:255',
                'email' => 'nullable|email|unique:users,email',
                'google_id' => 'nullable|string',
                'password' => 'nullable|string|min:6',
                'user_role' => 'nullable|string',
                'subscribe_status' => 'nullable|string',
                'phone' => 'nullable|string|max:20',
                'address' => 'nullable|string',
                'state' => 'nullable|string|max:100',
                'postal_code' => 'nullable|string|max:20',
                'country' => 'nullable|string|max:100',
                'date_of_birth' => 'nullable|date',
                'gender' => 'nullable|string',
                'age' => 'nullable|integer',
                'is_active' => 'nullable|boolean',
                'profile_image' => 'nullable|string',
                'bio' => 'nullable|string',
                'social_media' => 'nullable|string',
                'city' => 'nullable|string|max:100',
    
                // Client validation rules
                'company_name' => 'nullable|string|max:255',
                'industry' => 'nullable|string|max:255',
                'notes' => 'nullable|string',
            
        ];
    }
}
